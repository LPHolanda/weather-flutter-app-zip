package com.example.weather_mobile_engineer_test_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
